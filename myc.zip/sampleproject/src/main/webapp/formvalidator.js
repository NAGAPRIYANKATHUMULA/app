var dep=0;
var btn=0;
function zipCodeValidator(zipCode)
{
	matches=zipCode.match(/\b\d{5}\b/g);
	startWith=/^9[0-9].*$/;
	if(matches)
		{
			if(startWith.test(matches[0]))
				{
					document.getElementById('plansButton').disabled=false;
				}
		}
}
	function myself()
	{
		document.getElementById('myselfdate').innerHTML='<input type="date" name="mdate" id="mdate" onchange="amountPartner()"> <input type="button" value="X" name="remove" id="remove" onclick="remove()">';		
	}
	function mypartner()
	{
		document.getElementById('My partner').innerHTML='<input type="date" name="mdate" id="mdate"> <input type="button" value="X" name="remove" id="remove" onclick="remove()" >';

	}
	
	
	function addDependent()
	{
	dep++;
	document.getElementById('dependentDate').innerHTML+= '<input type="date" name="ddate'+dep+'" id="ddate'+dep+'"> <input type="button" value="X" onclick="removeDependent(this.id)" id="remove'+dep+'"> <div><input type="button" name="dependent" id="dependent'+dep+'" value="dependent" onclick="addDependent()"></div>';
	document.getElementsByName("dependent")[btn].disabled = true;
	btn++;
	}

		
	function remove()
	{
		var elemDate=document.getElementById("mdate");
		var elemRemove=document.getElementById("remove");
		elemDate.parentElement.removeChild(elemDate);
		elemRemove.parentElement.removeChild(elemRemove);
	}
	function removeDependent(a)
	{
	var elemDate = document.getElementById("ddate"+a[3]);
	var elemRemove = document.getElementById("remove"+a[3]);
	var elemButton = document.getElementById("dependent"+a[3]);
	elemDate.parentElement.removeChild(elemDate);
	elemRemove.parentElement.removeChild(elemRemove);
	elemButton.parentElement.removeChild(elemButton);
	console.log(document.getElementsByName("dependent").length);
	console.log(btn);
	btn--;
	document.getElementsByName("dependent")[btn].disabled = false;
	}
	
	
	function amountPartner(mdate){
		
		var s="Minimum PPO coverage starts at: ";
		 if(confirm(mdate)){
			 alert(s+"$990");
		 }
	}



