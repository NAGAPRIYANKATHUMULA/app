package com.sampleproject.dao;

import java.util.List;
import com.sampleproject.model.Plans;
 
public interface PlansDao {
	    public List<Plans> getAllPlans();
	    public Plans getPlan(int zipid);
	}
