package com.sampleproject.dao;

import java.util.List;

import com.sampleproject.model.Plans;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sampleproject.model.Plans;

 @Repository
 public class PlansDaoImpl implements PlansDao {

	 @Autowired
	 private SessionFactory sessionFactory;
	
	 public List<Plans> getAllPlans() {

		 return sessionFactory.getCurrentSession().createQuery("from Plans")
	                .list();
	}

	public Plans getPlan(int zipid) {
		 return (Plans) sessionFactory.getCurrentSession().get(
	                Plans.class, zipid);
		
	}

}
