package com.sampleproject.model;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EMP_TBL")
public class Plans {
	
	public class Seeplan implements Serializable {
	 
	    @Id
	    private int zipid;
	 
	    @Column
	    private String plan1;
	 
	    @Column
	    private String plan2;
	 
	    @Column
	    private String plan3;

		public int getZipid() {
			return zipid;
		}

		public void setZipid(int zipid) {
			this.zipid = zipid;
		}

		public String getPlan1() {
			return plan1;
		}

		public void setPlan1(String plan1) {
			this.plan1 = plan1;
		}

		public String getPlan2() {
			return plan2;
		}

		public void setPlan2(String plan2) {
			this.plan2 = plan2;
		}

		public String getPlan3() {
			return plan3;
		}

		public void setPlan3(String plan3) {
			this.plan3 = plan3;
		}
	 
	    
	 
	  
	 
	}
}
