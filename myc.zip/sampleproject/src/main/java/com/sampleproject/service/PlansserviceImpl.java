package com.sampleproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
 
import com.sampleproject.dao.PlansDao;
import com.sampleproject.model.Plans;
@Service
@Transactional
public class PlansserviceImpl implements Plansservice {
	
	 @Autowired
	    private PlansDao PlansDao;

	public List<Plans> getAllPlans() {
		 return PlansDao.getAllPlans();
	}

	public Plans getPlan(int zipid) {
		 return PlansDao.getPlan(zipid);
		
	}

}
