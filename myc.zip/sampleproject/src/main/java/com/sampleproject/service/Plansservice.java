package com.sampleproject.service;
import java.util.List;

import com.sampleproject.model.Plans;


public interface Plansservice {
	
	   
	 
	    public List<Plans> getAllPlans() ;
	
	 
	  
	    public Plans getPlan(int zipid);
	 
	    
	
}
