package com.sampleproject.controller;

import java.io.IOException;
import java.util.List;
 
import javax.servlet.http.HttpServletRequest;
 
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.sampleproject.model.Plans;
import com.sampleproject.service.Plansservice;

@Controller
public class PlansController {

	 @Autowired
	    private Plansservice plansservice;
	 
	/* @RequestMapping(value = "/")
	    public ModelAndView listEmployee(ModelAndView model) throws IOException {
	        List<Plans> listPlan = Plansservice.getAllPlans();
	        model.addObject("listPlan", listPlan);
	        model.setViewName("index");
	        return model;
	 }*/
}
