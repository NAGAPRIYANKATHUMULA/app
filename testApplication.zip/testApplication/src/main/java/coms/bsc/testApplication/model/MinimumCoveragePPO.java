package coms.bsc.testApplication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

public class MinimumCoveragePPO {
	
	@Id
	private int id;
	@Column
	private double monthly_premium;
	@Column
	private double med_ded_ind;
	@Column
	private double med_ded_family;
	@Column
	private double out_ind;
	@Column
	private double out_family;
	@Column
	private double pharmacy_ded_ind;
	@Column
	private double pharmacy_ded_family;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getMonthly_premium() {
		return monthly_premium;
	}
	public void setMonthly_premium(double monthly_premium) {
		this.monthly_premium = monthly_premium;
	}
	public double getMed_ded_ind() {
		return med_ded_ind;
	}
	public void setMed_ded_ind(double med_ded_ind) {
		this.med_ded_ind = med_ded_ind;
	}
	public double getMed_ded_family() {
		return med_ded_family;
	}
	public void setMed_ded_family(double med_ded_family) {
		this.med_ded_family = med_ded_family;
	}
	public double getOut_ind() {
		return out_ind;
	}
	public void setOut_ind(double out_ind) {
		this.out_ind = out_ind;
	}
	public double getOut_family() {
		return out_family;
	}
	public void setOut_family(double out_family) {
		this.out_family = out_family;
	}
	public double getPharmacy_ded_ind() {
		return pharmacy_ded_ind;
	}
	public void setPharmacy_ded_ind(double pharmacy_ded_ind) {
		this.pharmacy_ded_ind = pharmacy_ded_ind;
	}
	public double getPharmacy_ded_family() {
		return pharmacy_ded_family;
	}
	public void setPharmacy_ded_family(double pharmacy_ded_family) {
		this.pharmacy_ded_family = pharmacy_ded_family;
	}
	
	@Override
	public String toString() {
		return "MinimumCoveragePPO [monthly_premium=" + monthly_premium + "]";
	}
	
	

}
