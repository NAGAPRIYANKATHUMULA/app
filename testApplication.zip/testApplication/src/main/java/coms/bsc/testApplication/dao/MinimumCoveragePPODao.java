package coms.bsc.testApplication.dao;





public interface MinimumCoveragePPODao {
	
	/*public List<MinimumCoveragePPO> listMinimumCoveragePPO();
	
	public MinimumCoveragePPO getMinimumCoveragePPOById(int zip_id);
	
	public int getID();
	
	*/
	
	
	public Double getPlanRate(int ZIP_id);

}
