

package coms.bsc.testApplication.impl;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import coms.bsc.testApplication.dao.MinimumCoveragePPODao;
import coms.bsc.testApplication.model.MinimumCoveragePPO;

@Repository
public class MinimumCoveragePPODaoImpl implements MinimumCoveragePPODao {
	

	private SessionFactory sessionFactory;


	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	
	
	 
	/*
    public MinimumCoveragePPO getMinimumCoveragePPOById(int zip_id) {
		
		Session session = this.sessionFactory.getCurrentSession();		
		MinimumCoveragePPO mcp = (MinimumCoveragePPO) session.load(MinimumCoveragePPO.class, new Integer(zip_id));
		logger.info("MinimumCoveragePPO loaded successfully, MinimumCoveragePPO details="+mcp);
		return mcp;
		
	}*/


  /*  @SuppressWarnings("unchecked")
	public List<MinimumCoveragePPO[]> listMinimumCoveragePPO() {
			Session session = this.sessionFactory.getCurrentSession();
			List<MinimumCoveragePPO[]> mcpList = session.createQuery("Select monthly_premium from MinimumCoveragePPO where zip_id:=ZIPid").list();
			for (MinimumCoveragePPO[] minimumCoveragePPO : mcpList) {
				Double mp = (Double)MinimumCoveragePPO[1];
			}
			
			return mcpList;
		}*/
	 
	 public Double getPlanRate(int ZIP_id){
		  
		System.out.println("ZipID>>>"+ZIP_id);
		Double i= 0.0;
		/* Session session = this.sessionFactory.getCurrentSession();
		 List<Double> mcpList = session.createQuery("Select monthly_premium from MinimumCoveragePPO where zip_id=ZIP_id").list();
		 for (Double monthlyPremium : mcpList){
			System.out.println("Monthly premium>>>"+monthlyPremium);
			i=monthlyPremium;
		 }*/
		
		 Session session = this.sessionFactory.getCurrentSession();
		 String HQL = "select monthly_premium from MinimumCoveragePPO where zip_id=?";
		
		 org.hibernate.Query query = session.createQuery(HQL);
		 query.setDouble(0, ZIP_id);
		 List<Double> mcpList = query.list();
		 for (Double monthlyPremium : mcpList){
				//System.out.println("Monthly premium>>>"+monthlyPremium);
				i=monthlyPremium;
		 }
		return i;
	 }

	
}
