package coms.bsc.testApplication.service;
import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Service;

import coms.bsc.testApplication.model.MinimumCoveragePPO;

@Service
public interface MinimumCoveragePPOService {
	
	/*public MinimumCoveragePPO getMinimumCoveragePPOById(int zip_id);
	
	public List<MinimumCoveragePPO> listMinimumCoveragePPO();
	
	public int getID();
	
	 Session session = this.sessionFactory.getCurrentSession();
		 String HQL = "Select monthly_premium from MinimumCoveragePPO where zip_id:=id";
		 org.hibernate.Query query = session.createQuery(HQL);
		 query.setParameter("id", ZIP_id);		
		 List<Double> mcpList = query.list();
	
	*/
	

	
	public Double getPlanRate(int ZIP_id);
}
