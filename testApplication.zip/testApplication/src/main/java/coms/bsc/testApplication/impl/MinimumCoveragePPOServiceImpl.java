package coms.bsc.testApplication.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import coms.bsc.testApplication.service.MinimumCoveragePPOService;
import coms.bsc.testApplication.dao.MinimumCoveragePPODao;
import coms.bsc.testApplication.model.MinimumCoveragePPO;

@Service
public class MinimumCoveragePPOServiceImpl implements MinimumCoveragePPOService{

	private MinimumCoveragePPODao minimumCoveragePPODao;


	public void setMinimumCoveragePPODao(MinimumCoveragePPODao minimumCoveragePPODao) {
		this.minimumCoveragePPODao = minimumCoveragePPODao;
	}


	/*@Transactional
	public List<MinimumCoveragePPO> listMinimumCoveragePPO() {
		return this.minimumCoveragePPODao.listMinimumCoveragePPO();
		
	}

	@Transactional
	public MinimumCoveragePPO getMinimumCoveragePPOById(int zip_id) {	
		
			return this.minimumCoveragePPODao.getMinimumCoveragePPOById(zip_id);
		
	}*/
	
	@Transactional
	public Double getPlanRate(int ZIP_id){
		return this.minimumCoveragePPODao.getPlanRate(ZIP_id);
	}

}
